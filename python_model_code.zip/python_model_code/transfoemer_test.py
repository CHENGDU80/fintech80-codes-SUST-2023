import torch
import torch.nn as nn
import torch.nn.functional as F
import math
import numpy as np

class MultiHeadAttention(nn.Module):
    def __init__(self, d_model, num_heads):
        super(MultiHeadAttention, self).__init__()
        self.d_model = d_model
        self.num_heads = num_heads
        self.head_dim = d_model // num_heads
        self.query = nn.Linear(d_model, d_model)
        self.key = nn.Linear(d_model, d_model)
        self.value = nn.Linear(d_model, d_model)
        self.fc = nn.Linear(d_model, d_model)

    def forward(self, x, mask=None):
        batch_size = x.shape[0]
        Q = self.query(x).view(batch_size, -1, self.num_heads, self.head_dim)
        K = self.key(x).view(batch_size, -1, self.num_heads, self.head_dim)
        V = self.value(x).view(batch_size, -1, self.num_heads, self.head_dim)
        Q = Q.permute(0, 2, 1, 3)
        K = K.permute(0, 2, 1, 3)
        V = V.permute(0, 2, 1, 3)
        scores = torch.matmul(Q, K.permute(0, 1,3, 2))
        scores = scores / self.head_dim ** 0.5
        if mask is not None:
            scores = scores.masked_fill(mask == 0, -1e9)
        attn_weights = F.softmax(scores, dim=-1)
        attn_output = torch.matmul(attn_weights, V)
        attn_output = attn_output.permute(0, 2, 1, 3).contiguous()
        attn_output = attn_output.view(batch_size, -1, self.d_model)
        attn_output = self.fc(attn_output)
        return attn_output, attn_weights

class PositionalEncoding(nn.Module):
    def __init__(self, d_model, max_len=5000):
        super(PositionalEncoding, self).__init__()
        self.d_model = d_model
        pe = torch.zeros(max_len, d_model)
        position = torch.arange(0, max_len, dtype=torch.float).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, d_model, 2).float() * (-math.log(10000.0) / d_model))
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        pe = pe.unsqueeze(0)
        self.register_buffer('pe', pe)

    def forward(self, x):
        x = x * math.sqrt(self.d_model)
        seq_len =x.size(1)
        x = x + self.pe[:, :seq_len, :]
        return x

class TransformerBlock(nn.Module):
    def __init__(self, d_model, num_heads, dropout_rate=0.1):
        super(TransformerBlock, self).__init__()
        self.multihead_attention = MultiHeadAttention(d_model, num_heads)
        self.norm1 = nn.LayerNorm(d_model)
        self.dropout1 = nn.Dropout(dropout_rate)
        self.fc1 = nn.Linear(d_model, 4 * d_model)
        self.gelu = nn.GELU()
        self.fc2 = nn.Linear(4 * d_model, d_model)
        self.norm2 = nn.LayerNorm(d_model)
        self.dropout2 = nn.Dropout(dropout_rate)

    def forward(self, x, mask=None):
        attn_output, attn_weights = self.multihead_attention(x, mask=mask)
        x = x + self.dropout1(self.norm1(attn_output))
        fc_output = self.fc2(self.gelu(self.fc1(x)))
        x = x + self.dropout2(self.norm2(fc_output))
        return x, attn_weights

class TransformerEncoder(nn.Module):
    def __init__(self, num_layers, d_model, num_heads, dropout_rate=0.1):
        super(TransformerEncoder, self).__init__()
        self.num_layers = num_layers
        self.d_model = d_model
        self.layers = nn.ModuleList([TransformerBlock(d_model, num_heads, dropout_rate) for _ in range(num_layers)])
        
    def forward(self, x, mask=None):
        for i in range(self.num_layers):
            x, attn_weights = self.layers[i](x, mask=mask)
        return x, attn_weights

class Transformer(nn.Module):
    def __init__(self, num_layers, d_model, num_heads, hidden_dim, dropout_rate=0.1):
        super(Transformer, self).__init__()
        self.encoder = TransformerEncoder(num_layers, d_model, num_heads, dropout_rate)
        self.fc = nn.Linear(d_model, hidden_dim)
        self.dropout = nn.Dropout(dropout_rate)
        self.output_layer = nn.Linear(hidden_dim, 5105)

    def forward(self, x, mask=None):
        x, attn_weights = self.encoder(x, mask=mask)
        x = torch.mean(x, dim=1)
        x = self.dropout(F.relu(self.fc(x)))
        x = self.output_layer(x)
        return x.squeeze(), attn_weights

# model = Transformer(num_layers=3, d_model=10000, num_heads=4, hidden_dim=8000)
# print(model)
# print(np.zeros((8, 400)).shape)
# a = torch.Tensor(np.zeros((8, 1, 10000)))
# print(model(a)[0].shape)