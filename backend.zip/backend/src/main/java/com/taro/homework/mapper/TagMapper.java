package com.taro.homework.mapper;

import com.taro.homework.entity.Tag;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author taro
 * @since 2023-10-30
 */
public interface TagMapper extends BaseMapper<Tag> {

}
