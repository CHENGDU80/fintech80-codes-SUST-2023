package com.taro.homework.controller;


import com.baomidou.mybatisplus.core.metadata.IPage;
import com.taro.homework.config.DatabaseConfig;
import com.taro.homework.entity.ApiResult;
import com.taro.homework.entity.News;
import com.taro.homework.service.NewsService;
import com.taro.homework.util.ApiResultHandler;
import com.taro.homework.util.DataImportUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author taro
 * @since 2023-10-30
 */
@RestController
@RequestMapping("/api/news")
public class NewsController {

    @Autowired
    NewsService newsService;

    @Autowired
    DatabaseConfig databaseConfig;

    @RequestMapping("/list")
    public ApiResult getAllNewsByKeywords(@RequestParam(value = "keyword", required = false) String keyword,
                                            @RequestParam("page") int page,
                                            @RequestParam("size") int size) {
        if (keyword == null)
            return ApiResultHandler.success(newsService.getAllNewsOrderByDate(page, size));
        else
            return ApiResultHandler.success(newsService.getAllNewsByKeywords(keyword, page, size));
    }

    @RequestMapping("/list/macro")
    public ApiResult getIndustryImpNewsList(@RequestParam("page") int page,
                                            @RequestParam("size") int size) {
        return ApiResultHandler.success(newsService.getAllMacroNewsOrderByDate(page, size));
    }

    @RequestMapping("/{id}")
    public ApiResult getOneNews(@PathVariable("id") int id) {
        return ApiResultHandler.success(newsService.getById(id));
    }

    @RequestMapping("/list/hotdot")
    public ApiResult getAllHotNews(@RequestParam("page") int page,
                                   @RequestParam("size") int size) {
        try {
            String hotPath = databaseConfig.FILE_PATH_HOT_DOT;
            String keyPath = databaseConfig.FILE_PATH_KEYWORD;
            Process proc = DataImportUtil.buildProcess("python", hotPath);
            String res = DataImportUtil.readInputStream(proc.getInputStream());
            String errorInfo;
            if (!(errorInfo = DataImportUtil.readInputStream(proc.getErrorStream())).equals(""))
                return ApiResultHandler.buildApiResult(302, "Process Error!", errorInfo);
            List<String> ss = Arrays.stream(res.split("\n")).filter(Objects::nonNull).collect(Collectors.toList());
            proc.waitFor();
            List<String> answerStrings = new ArrayList<>();
            for (String s: ss) {
                Process p = DataImportUtil.buildProcess("python", keyPath, new String[]{s});
                String res1 = DataImportUtil.readInputStream(p.getInputStream());
                if (!DataImportUtil.readInputStream(p.getErrorStream()).equals(""))
                    return ApiResultHandler.buildApiResult(302, "Process Error!", null);
                p.waitFor();
                List<String> ss1 = Arrays.stream(res1.split("\n")).filter(Objects::nonNull).collect(Collectors.toList());
                IPage<News> newsIPage = newsService.getAllHotNewsWithKeywords(ss1.get(0), ss1.get(1), ss1.get(2), page, size);
                if (newsIPage.getTotal() > 0)
                    answerStrings.add(s);
//                System.out.println(res1);
            }
            return ApiResultHandler.success(answerStrings);
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
        return ApiResultHandler.buildApiResult(303, "undefine error", null);
    }

    @RequestMapping("/list/timeline")
    public ApiResult getNewsTimeline(@RequestParam("page") int page,
                                     @RequestParam("size") int size,
                                     @RequestParam("content") String content) {
        try {
            System.out.println(content);
            Process p = DataImportUtil.buildProcess(
                    databaseConfig.PYTHON_ENVIRONMENT,
                    databaseConfig.FILE_PATH_KEYWORD,
                    new String[]{content});
            String res = DataImportUtil.readInputStream(p.getInputStream());
            p.waitFor();
            List<String> ss = Arrays.stream(res.split("\n")).filter(Objects::nonNull).collect(Collectors.toList());
            return ApiResultHandler.success(newsService.getAllHotNewsWithKeywords(ss.get(0), ss.get(1), ss.get(2), page, size));
        } catch (IOException | InterruptedException e) {
            throw new RuntimeException(e);
        }
    }
}
