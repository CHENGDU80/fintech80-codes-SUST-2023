package com.taro.homework.mapper;

import com.taro.homework.entity.UserFollowStock;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author taro
 * @since 2023-10-30
 */
@Mapper
public interface UserFollowStockMapper extends BaseMapper<UserFollowStock> {

}
