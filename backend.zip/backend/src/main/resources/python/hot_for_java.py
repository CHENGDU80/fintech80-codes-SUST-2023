#-*- coding: utf-8
import requests
from bs4 import BeautifulSoup
import json

url = 'https://tophub.today/c/{}'.format('finance')
headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36"}
try:
    r = requests.get(url,timeout = 30,headers=headers)
    html = r.text
except:
    raise "please inspect your url or setup"
# print(html)
soup = BeautifulSoup(html, 'html.parser')
con = soup.find('div',attrs={'class':'bc-cc'})
con_list = con.find_all('div', class_="cc-cd")
result = list()
for i in con_list:  
    author = i.find('div', class_='cc-cd-lb').get_text() # 获取平台名字
    if author == ' 第一财经':
        time = i.find('div', class_='i-h').get_text() # 获取最近更新
        link = i.find('div', class_='cc-cd-cb-l').find_all('a') # 获取所有链接  
        for k in link:
#             print(k)
            href = k['href']
            num = k.find('span', class_='s').get_text()
            title = str(k.find('span', class_='t').get_text())
            hot = str(k.find('span', class_='e').get_text())
            print(title)
            # result.append(title)
# print(result)
# print('&'.join(result))
