package com.taro.homework.controller;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.taro.homework.config.DatabaseConfig;
import com.taro.homework.entity.ApiResult;
import com.taro.homework.entity.News;
import com.taro.homework.entity.Stock;
import com.taro.homework.service.MarketService;
import com.taro.homework.service.NewsService;
import com.taro.homework.service.StockService;
import com.taro.homework.util.ApiResultHandler;
import com.taro.homework.util.DataExportUtil;
import com.taro.homework.util.DataImportUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/emotion")
public class EmotionController {

    @Autowired
    NewsService newsService;

    @Autowired
    StockService stockService;

    @Autowired
    MarketService marketService;

    @Autowired
    DatabaseConfig databaseConfig;

    @RequestMapping("/news/{id}")
    public ApiResult getNewsEmotionAnalysis(@PathVariable("id") int id) {
//        DataImportUtil.buildProcess();
        return ApiResultHandler.success(0.0f);
    }

    @RequestMapping("/stock/{ts_code}")
    public ApiResult analyseStockEmotion(@PathVariable("ts_code") String ts_code) throws IOException {
        Stock stock = stockService.getById(ts_code);
        List<News> newsList = newsService.getAllNewsByKeywords(stock.getName(), 1, 10).getRecords();
        List<String> ss = newsList.stream().map(News::getContent).collect(Collectors.toList());
        DataExportUtil.toFile(databaseConfig.EXPORT_NEWS, DataExportUtil.toString(ss));
//        System.out.println(ss);
        Process process = DataImportUtil.buildProcess(databaseConfig.PYTHON_ENVIRONMENT, databaseConfig.FILE_PATH_MODEL, new String[]{ts_code, databaseConfig.EXPORT_NEWS});
        System.out.println(DataImportUtil.readInputStream(process.getErrorStream()));
        String[] res_split = DataImportUtil.readInputStream(process.getInputStream()).split("@");
        System.out.println(Arrays.asList(res_split));
        Float returnRate = Float.parseFloat(res_split[1]);
        Float emoFactor = Float.parseFloat(res_split[2]);
        Map<String, Float> resMap = new HashMap<>();
        resMap.put("rate", returnRate);
        resMap.put("emo_factor", emoFactor);
        return ApiResultHandler.success(resMap);
    }

    @RequestMapping("/field")
    public ApiResult analyseFieldEmotion(@RequestParam("field_name") String fieldName) {
        return ApiResultHandler.success(0.0f);
    }
}
