package com.taro.homework.entity;

import lombok.Data;

@Data
public class ApiResult<T> {

    private Integer code;

    private String message;

    private T data;
}
