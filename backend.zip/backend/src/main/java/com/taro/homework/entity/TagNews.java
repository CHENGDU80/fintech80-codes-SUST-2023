package com.taro.homework.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * 
 * </p>
 *
 * @author taro
 * @since 2023-10-30
 */
@Getter
@Setter
@TableName("tag_news")
@ApiModel(value = "TagNews对象", description = "")
public class TagNews implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableField("tag_id")
    private Integer tagId;

    @TableField("news_id")
    private Integer newsId;


}
