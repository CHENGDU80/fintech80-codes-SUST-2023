package com.taro.homework.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author taro
 * @since 2023-10-30
 */
@RestController
@RequestMapping("/api/user")
public class UserController {

}
