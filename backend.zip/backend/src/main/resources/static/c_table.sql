drop table if exists user_follow_stock;
drop table if exists tag_news;
drop table if exists tag;
drop table if exists market;
drop table if exists stock;
drop table if exists news;
drop table if exists user;

create table user(
                     id INT AUTO_INCREMENT PRIMARY KEY ,
                     `name` VARCHAR(10) NOT NULL ,
                     `password` VARCHAR(20) NOT NULL
);

create table news(
                     id INT AUTO_INCREMENT PRIMARY KEY ,
                     title VARCHAR(100) ,
                     content VARCHAR(1024) ,
                     released_time DATETIME NOT NULL,
                     src VARCHAR(10) NOT NULL ,
                     channel VARCHAR(200)
);

create table stock(
                      ts_code VARCHAR(10) PRIMARY KEY ,
                      symbol VARCHAR(10) NOT NULL ,
                      `name` VARCHAR(10) NOT NULL ,
                      area VARCHAR(10) NOT NULL ,
                      industry VARCHAR(10) NOT NULL ,
                      fullname VARCHAR(100) NOT NULL ,
                      enname VARCHAR(100) NOT NULL ,
                      cnspell VARCHAR(10) NOT NULL ,
                      market VARCHAR(10) NOT NULL ,
                      `exchange` VARCHAR(10) NOT NULL ,
                      curr_type VARCHAR(10) NOT NULL ,
                      list_status VARCHAR(20) NOT NULL ,
                      list_date DATETIME NOT NULL,
                      delist_date DATETIME,
                      is_hs VARCHAR(1) ,
                      act_name VARCHAR(100),
                      act_ent_type VARCHAR(10)
);

create table market(
                       id INT AUTO_INCREMENT PRIMARY KEY ,
                       ts_code VARCHAR(10) NOT NULL ,
                       trade_date DATETIME NOT NULL ,
                       `open` FLOAT NOT NULL ,
                       high FLOAT NOT NULL ,
                       low FLOAT NOT NULL ,
                       `close` FLOAT NOT NULL ,
                       `change` FLOAT NOT NULL ,
                       pct_chg FLOAT NOT NULL ,
                       vol FLOAT NOT NULL ,
                       amount FLOAT NOT NULL,
                       CONSTRAINT FOREIGN KEY (ts_code) REFERENCES stock(ts_code)
);

create table tag (
                     id INT AUTO_INCREMENT PRIMARY KEY ,
                     `name` varchar(10) NOT NULL
);

create table tag_news(
                         tag_id INT NOT NULL ,
                         news_id INT NOT NULL ,
                         CONSTRAINT FOREIGN KEY (tag_id) REFERENCES tag(id),
                         CONSTRAINT FOREIGN KEY (news_id) REFERENCES news(id)
);

create table user_follow_stock(
                                  user_id INT NOT NULL ,
                                  ts_code VARCHAR(10) NOT NULL ,
                                  followed BOOLEAN NOT NULL ,
                                  CONSTRAINT FOREIGN KEY (user_id) REFERENCES user(id),
                                  CONSTRAINT FOREIGN KEY (ts_code) REFERENCES stock(ts_code),
                                  CONSTRAINT UNIQUE (user_id, ts_code)
);
