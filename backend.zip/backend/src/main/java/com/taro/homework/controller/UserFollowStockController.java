package com.taro.homework.controller;


import com.taro.homework.entity.ApiResult;
import com.taro.homework.entity.Stock;
import com.taro.homework.entity.UserFollowStock;
import com.taro.homework.mapper.UserMapper;
import com.taro.homework.service.StockService;
import com.taro.homework.service.UserFollowStockService;
import com.taro.homework.service.UserService;
import com.taro.homework.util.ApiResultHandler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author taro
 * @since 2023-10-30
 */
@RestController
@RequestMapping("/api/user-follow-stock")
public class UserFollowStockController {

    @Autowired
    public UserFollowStockService userFollowStockService;

    @Autowired
    public UserService userService;

    @RequestMapping("/follow")
    public ApiResult follow(@RequestParam("username") String username,
                            @RequestParam("ts_code") String ts_code) {
        UserFollowStock userFollowStock = new UserFollowStock(userService.getId(username), ts_code, true);
        if (userFollowStockService.insertOrUpdateUfs(userFollowStock))
            return ApiResultHandler.success();
        else
            return ApiResultHandler.buildApiResult(301, "插入失败", null);
    }

    @RequestMapping("/unfollow")
    public ApiResult unfollow(@RequestParam("username") String username,
                              @RequestParam("ts_code") String ts_code) {
        if (userFollowStockService.insertOrUpdateUfs(new UserFollowStock(userService.getId(username), ts_code, false)))
            return ApiResultHandler.success();
        else
            return ApiResultHandler.buildApiResult(301, "保存失败", null);
    }
}
