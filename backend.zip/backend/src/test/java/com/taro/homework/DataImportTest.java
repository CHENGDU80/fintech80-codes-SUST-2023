package com.taro.homework;

import com.alibaba.fastjson.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.taro.homework.config.DatabaseConfig;
import com.taro.homework.controller.UserFollowStockController;
import com.taro.homework.entity.User;
import com.taro.homework.service.UserService;
import com.taro.homework.util.DataImportUtil;
import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import java.io.*;
import java.net.URI;
import java.net.URISyntaxException;
import java.nio.file.Files;
import java.sql.*;
import java.util.*;
import java.util.stream.Collectors;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@ComponentScan(basePackages = "com.taro.homework.config")
public class DataImportTest {

    @Autowired
    UserService userService;

    @Autowired
    UserFollowStockController userFollowStockController;
    @BeforeClass
    public static void creatTable() throws SQLException, IOException, URISyntaxException {
        Connection conn = DatabaseConfig.getDatabaseConfig().getConnection();
        conn.setAutoCommit(false);
        URI uri = DataImportUtil.class.getClassLoader().getResource("static\\c_table.sql").toURI();
        BufferedReader reader = new BufferedReader(new InputStreamReader(Files.newInputStream(new File(uri).toPath())));
        StringBuilder sb = new StringBuilder();
        String line = null;
        while ((line = reader.readLine()) != null) {
            sb.append(line + "\n");
        }

        String[] sqlStatements = sb.toString().split(";");
        Statement stmt = conn.createStatement();
        for (String sql : sqlStatements) {
            if (!sql.trim().isEmpty()) {
                stmt.addBatch(sql);
            }
        }

        stmt.executeBatch();
        conn.commit();
        conn.close();
    }

    @Test
    public void importData() throws SQLException, URISyntaxException, IOException {
        importUser();
        importNews();
        importStock();
        importMarket();
        importUserFollow();
    }

    public void importUser() {
        User user = new User("checker", "123456");
        userService.save(user);
    }

    public void importUserFollow() {
        userFollowStockController.follow("checker", "600519.SH");
        userFollowStockController.follow("checker", "600721.SH");
        userFollowStockController.follow("checker", "000062.SZ");
        userFollowStockController.follow("checker", "835305.BJ");
        userFollowStockController.follow("checker", "688696.SH");
        userFollowStockController.follow("checker", "605337.SH");
        userFollowStockController.follow("checker", "605289.SH");
        userFollowStockController.follow("checker", "605122.SH");
        userFollowStockController.follow("checker", "603906.SH");
        userFollowStockController.follow("checker", "603877.SH");
    }


    public void importStock() throws URISyntaxException, SQLException {
        List<List<String>> stockList = DataImportUtil.readCsv("static\\all_stock.csv");
        stockList.forEach(strings -> strings.remove(0));
        String sql = "insert into stock (ts_code, symbol, name, area, industry, fullname, enname, cnspell, market, exchange, curr_type, list_status, list_date, delist_date, is_hs, act_name, act_ent_type) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);";
        Connection conn = DatabaseConfig.getDatabaseConfig().getConnection();
        HashMap<Integer, String> typeMap = new HashMap<>();
        typeMap.put(12, "date");
        typeMap.put(13, "date");
        DataImportUtil.dispose(conn, stockList, sql, typeMap);
        conn.close();
    }

    public void importNews() throws IOException, URISyntaxException, SQLException {
        String dirPath = "static/real-time/news/";
        PathMatchingResourcePatternResolver resolver = new PathMatchingResourcePatternResolver();
        // 通过classpath:获取resource folder下的所有文件
        Resource[] resources = resolver.getResources("classpath:"+dirPath+"*");
        String dirPath2 = dirPath.replace('/', '\\');
        for (Resource resource : resources) {
            // 获取文件名
            String fileName = resource.getFilename();
            List<List<String>> newsList = DataImportUtil.readCsv(dirPath2 + fileName);
            if (fileName != null && fileName.contains("sina")) {
                newsList.forEach(strings -> {
                    String datetime = strings.get(1);
                    String content = strings.get(2);
                    String title = content.substring(0, content.indexOf('】')+1);
                    content = content.substring(content.indexOf('】')+1);
                    String channels = strings.get(3);
                    strings.clear();
                    strings.add(title);
                    strings.add(content);
                    strings.add(datetime);
                    strings.add("sina");
                    strings.add(channels);
//                    System.out.println(strings);
                });
                Connection conn = DatabaseConfig.getDatabaseConfig().getConnection();
                HashMap<Integer, String> typeMap = new HashMap<>();
                String sql = "insert into news (title, content, released_time, src, channel) values (?, ?, ?, ?, ?);";
                DataImportUtil.dispose(
                        conn,
                        newsList.stream().filter(news -> !Objects.equals(news.get(0), "") && !Objects.equals(news.get(0), null)).collect(Collectors.toList()),
                        sql,
                        typeMap);
                conn.close();
            }
        }
    }

    public void importMarket() throws IOException, URISyntaxException, SQLException {
        String dirPath = "static/real-time/market/";
        PathMatchingResourcePatternResolver resolver = new PathMatchingResourcePatternResolver();
        // 通过classpath:获取resource folder下的所有文件
        Resource[] resources = resolver.getResources("classpath:"+dirPath+"*");
        String dirPath2 = dirPath.replace('/', '\\');
        for (Resource resource : resources) {
            // 获取文件名
            String fileName = resource.getFilename();
            List<List<String>> marketList = DataImportUtil.readCsv(dirPath2 + fileName);
            if (fileName != null) {
                marketList.forEach(strings -> {
                    strings.remove(0);
                });
                Connection conn = DatabaseConfig.getDatabaseConfig().getConnection();
                HashMap<Integer, String> typeMap = new HashMap<>();
                for (int i = 2; i <= 9; i++)
                    typeMap.put(i, "float");
                String sql = "insert into market (ts_code, trade_date, open, high, low, close, `change`, pct_chg, vol, amount) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?);";
                DataImportUtil.dispose(conn, marketList, sql, typeMap);
                conn.close();
            }
        }
    }
}
