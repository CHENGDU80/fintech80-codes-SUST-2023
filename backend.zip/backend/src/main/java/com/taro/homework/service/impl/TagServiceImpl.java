package com.taro.homework.service.impl;

import com.taro.homework.entity.Tag;
import com.taro.homework.mapper.TagMapper;
import com.taro.homework.service.TagService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author taro
 * @since 2023-10-30
 */
@Service
public class TagServiceImpl extends ServiceImpl<TagMapper, Tag> implements TagService {

}
