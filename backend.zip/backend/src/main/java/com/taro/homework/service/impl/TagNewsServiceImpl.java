package com.taro.homework.service.impl;

import com.taro.homework.entity.TagNews;
import com.taro.homework.mapper.TagNewsMapper;
import com.taro.homework.service.TagNewsService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author taro
 * @since 2023-10-30
 */
@Service
public class TagNewsServiceImpl extends ServiceImpl<TagNewsMapper, TagNews> implements TagNewsService {

}
