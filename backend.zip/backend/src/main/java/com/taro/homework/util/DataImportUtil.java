package com.taro.homework.util;

import io.swagger.models.auth.In;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVRecord;

import java.io.*;
import java.net.URI;
import java.net.URISyntaxException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Stream;

public class DataImportUtil {

    public static void dispose(Connection conn, List<List<String>> list, String sql, HashMap<Integer, String> typeMap) {
        dispose(conn, list, 0, true, 100, sql, typeMap);
    }

    public static void dispose(Connection conn, List<List<String>> list, Integer startRows, boolean includePrimaryKey, Integer size, String sql, HashMap<Integer, String> typeMap) {
        try {
            conn.setAutoCommit(false);  //  设置事物手动提交
            PreparedStatement ps = conn.prepareStatement(sql);
            for (int i = startRows; i < list.size(); i++) {
                List<String> ss = list.get(i);
//                System.out.println(ss);
                for (int j = 0; j < ss.size(); j++) {   //  遍历刚刚获取的数组
                    if (ss.get(j).equals(""))
                        ps.setObject(j+1, null);
                    else {
                        if (typeMap == null || typeMap.get(j) == null) {
                            ps.setObject(j + 1, ss.get(j).replace("\"", ""));    //  循环赋值
                        }else if (typeMap.get(j).equals("date"))
                            ps.setObject(j+1, mySqlFormatDate(ss.get(j)));
                        else if (typeMap.get(j).equals("float"))
                            ps.setFloat(j+1, Float.parseFloat(ss.get(j).replace(",", "")));
                    }
                }
                ps.addBatch();
                if (i % size == 0 && i != 0) {   //  如果i能整除size，即执行循环体
                    ps.executeBatch();           //  批量执行sql
                    conn.commit();               //  事物手动提交
                    conn.setAutoCommit(false);   //  重新设置事物为手动提交
                    ps = conn.prepareStatement(sql);   //  再次为ps对象赋值
                }
            }
            ps.executeBatch();  //  循环外提交是因为可能会出现循环内条件不成立而未提交过的情况
            conn.commit();      //  提交事物，避免脏数据（事物太长也有弊端）
            ps.close();         //  关闭资源
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static List<List<String>> readCsv(String resource) throws URISyntaxException {
        List<List<String>> res = new ArrayList<>();
        URI uri = DataImportUtil.class.getClassLoader().getResource(resource).toURI();
        try (Reader reader = Files.newBufferedReader(Paths.get(uri))) {
            Iterable<CSVRecord> records = CSVFormat.DEFAULT.parse(reader);
            boolean firstLine = true;
            for (CSVRecord record : records) {
                if (firstLine) {
                    firstLine = false;
                    continue;
                }
                List<String> ss = new ArrayList<>();
                for (String s: record) {
                    ss.add(s);
                }
                res.add(ss);
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        return res;
    }

    public static String readInputStream(InputStream stream) throws IOException {
        BufferedReader in = new BufferedReader(new InputStreamReader(stream));
        StringBuilder res = new StringBuilder();
        String line;
        while ((line = in.readLine()) != null) {
//            System.out.println(line);
            res.append(line+"\n");
        }
        in.close();
        return res.toString();
    }

    public static Process buildProcess(String pythonPath, String filePath) throws IOException {
        List<String> new_args = new ArrayList<>();
        new_args.add(pythonPath);
        new_args.add(filePath);
        return buildProcess((new_args.toArray(new String[0])));
    }
    public static Process buildProcess(String pythonPath, String filePath, String[] args) throws IOException {
        List<String> new_args = new ArrayList<>();
        new_args.add(pythonPath);
        new_args.add(filePath);
        new_args.addAll(Arrays.asList(args));
        return buildProcess(new_args.toArray(new String[0]));
    }

    public static Process buildProcess(String[] args) throws IOException {
        String filePath = "F:\\FIN\\hot_for_java.py";
        String[] args1 = new String[2];
        args1[0] = "python";
        args1[1] = filePath;

        ProcessBuilder processBuilder = new ProcessBuilder(args);

        processBuilder.environment().put("PYTHONIOENCODING", "utf-8");

        return processBuilder.start();
    }



    public static String mySqlFormatDate(String inputDate) {
//        System.out.println(inputDate);
        String sourceFormat = "yyyyMMdd"; // 输入日期字符串的格式
        String targetFormat = "yyyy-MM-dd"; // 目标日期字符串的格式

        DateTimeFormatter sourceFormatter = DateTimeFormatter.ofPattern(sourceFormat);
        DateTimeFormatter targetFormatter = DateTimeFormatter.ofPattern(targetFormat);

        LocalDate date = LocalDate.parse(inputDate, sourceFormatter);
        String formattedDate = date.format(targetFormatter);
//        System.out.println("Formatted Date: " + formattedDate);
        return formattedDate;
    }
}
