package com.taro.homework.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.taro.homework.entity.News;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.Map;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author taro
 * @since 2023-10-30
 */
public interface NewsService extends IService<News> {

    public IPage<News> getAllNewsByKeywords(String keyword, int page, int size);

    public IPage<News> getAllNewsOrderByDate(int page, int size);

    public IPage<Map<String, String>> getAllNewsByFieldOrderByDate(String fieldName, int page, int size);

    public IPage<Map<String, String>> getAllMacroNewsOrderByDate(int page, int size);

    int getNumberOfNews(String keyword);

    IPage<News> getAllHotNewsWithKeywords(String key1, String key2, String key3, int page, int size);


}
