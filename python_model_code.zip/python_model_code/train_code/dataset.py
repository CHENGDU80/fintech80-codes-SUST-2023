from torch.utils.data import DataLoader, Dataset
import pandas as pd
import numpy as np
from gensim.models import Word2Vec
import torch 
class KeywordDataset(Dataset):
    def __init__(self, dir):
        self.df = pd.read_csv(dir)
        self.keywords = self.df['keyword'].tolist()
        self.labels = self.df['next_day_label'].tolist()
        self.keyword_vectors = []
        for keyword in self.keywords:
            model = Word2Vec([[keyword]], vector_size=6000, window=5, min_count=1, workers=4)
            word_vector = model.wv[keyword]
            self.keyword_vectors.append(np.array(word_vector))

    def __getitem__(self, index):
        return (self.keyword_vectors[index]), (np.array(eval(self.labels[index])).astype(np.float32))
    def __len__(self):
        return len(self.keywords)
if __name__ == "__main__":
    dataset = KeywordDataset('/data/chenjt/chengdu/dataset_float_label/train.csv') #实例化
    train_loader = DataLoader(dataset=dataset, batch_size=8, shuffle=True, num_workers=2)  #再使用ataLoader来加载数据集
    print((dataset[0][0]).shape)
    print((dataset[0][1]).shape)
    print((dataset[0][1].dtype))