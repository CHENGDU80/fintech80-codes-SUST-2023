package com.taro.homework.mapper;

import com.taro.homework.entity.Market;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;
import java.util.Map;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author taro
 * @since 2023-10-30
 */
@Mapper
public interface MarketMapper extends BaseMapper<Market> {

    @Select("select trade_date, `open`, `close`, `high`, `low` from market where ts_code = #{ts_code} order by trade_date asc")
    public List<Market> getAllMarketOrderByDate(String ts_code);

    @Select("select s.ts_code, s.name, pct_chg, `close`  from market left join stock s on s.ts_code = market.ts_code where DATE(trade_date) = CURDATE() - INTERVAL #{day} DAY and s.industry = #{industryName} order by pct_chg ${order} limit #{limit}")
    public List<Map<String, String>> getAllMarketBeforeDays(String industryName, int day, int limit, String order);

    @Select("SELECT s.name, MAX(s.ts_code) AS ts_code, count(1) AS news_count FROM stock s INNER JOIN (select * from news where news.content LIKE CONCAT('%', #{industryName}, '%')) as `n` ON n.content LIKE CONCAT('%', s.name, '%') GROUP BY s.name ORDER BY news_count desc limit #{limit}")
    public List<Map<String, String>> getAllStocksHotByIndustry(String industryName, int limit);

    @Select("SELECT id, title, content, released_time FROM news where news.content LIKE CONCAT('%', #{industryName}, '%') and news.content LIKE CONCAT('%', (SELECT name from stock where ts_code=#{ts_code}), '%') ORDER BY released_time desc limit #{limit}")
    public List<Map<String, String>> getAllHotNewsByIndustryAndStock(String industryName, String ts_code, int limit);
}
