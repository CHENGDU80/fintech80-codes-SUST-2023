from snownlp import SnowNLP
import sys
def extract_keywords(text, num_keywords=5):
    s = SnowNLP(text)
    keywords = s.keywords(num_keywords)
    return keywords

args = sys.argv
# text = "标普确认龙湖集团投资级评级，认为龙湖流动性充足"
text = args[1]
# print(text)
num_keywords = 3
keywords = extract_keywords(text, num_keywords)
# print(keywords)
for key in keywords:
    print(key)

