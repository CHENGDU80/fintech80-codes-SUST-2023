package com.taro.homework.service;

import com.taro.homework.entity.Market;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;
import java.util.Map;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author taro
 * @since 2023-10-30
 */
public interface MarketService extends IService<Market> {

    public List<Market> getAllMarketOrderByDate(String ts_code);

    public List<Map<String, String>> getAllMarketBeforeDays(String industryName, int day, int limit, String order);

    public List<Map<String, String>> getAllStocksHotByIndustry(String industryName, int limit);

    public List<Map<String, String>> getAllHotNewsByIndustryAndStock(String industryName, String ts_code, int limit);

}
