package com.taro.homework.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.time.LocalDateTime;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 *
 * </p>
 *
 * @author taro
 * @since 2023-10-30
 */
@Data
@TableName("stock")
@ApiModel(value = "Stock对象", description = "")
public class Stock implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId("ts_code")
    private String tsCode;

    @TableField("symbol")
    private String symbol;

    @TableField("name")
    private String name;

    @TableField("area")
    private String area;

    @TableField("industry")
    private String industry;

    @TableField("fullname")
    private String fullname;

    @TableField("enname")
    private String enname;

    @TableField("cnspell")
    private String cnspell;

    @TableField("market")
    private String market;

    @TableField("exchange")
    private String exchange;

    @TableField("curr_type")
    private String currType;

    @TableField("list_status")
    private String listStatus;

    @TableField("list_date")
    private LocalDateTime listDate;

    @TableField("delist_date")
    private LocalDateTime delistDate;

    @TableField("is_hs")
    private String isHs;

    @TableField("act_name")
    private String actName;

    @TableField("act_ent_type")
    private String actEntType;


}
