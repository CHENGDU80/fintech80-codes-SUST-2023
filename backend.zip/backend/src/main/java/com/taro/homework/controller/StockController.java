package com.taro.homework.controller;


import com.taro.homework.entity.ApiResult;
import com.taro.homework.service.MarketService;
import com.taro.homework.service.StockService;
import com.taro.homework.util.ApiResultHandler;
import io.swagger.annotations.Api;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author taro
 * @since 2023-10-30
 */
@RestController
@CrossOrigin
@RequestMapping("/api/stock")
public class StockController {

    @Autowired
    StockService stockService;

    @Autowired
    MarketService marketService;

    @RequestMapping("/{ts_code}/emotion")
    public ApiResult getEmotionAnalysis(@PathVariable("ts_code") String ts_code) {
        return ApiResultHandler.success(0.0f);
    }

    @RequestMapping("/list")
    public ApiResult searchAllStocks(@RequestParam(value = "search_info", required = false) String info,
                                     @RequestParam("page") int page,
                                     @RequestParam("size") int size) {
        if (info == null)
            return ApiResultHandler.success(stockService.getAllStocksWithClose(6, page, size));
        else
            return ApiResultHandler.success(stockService.searchAllStocksByName(info, page, size));
    }

    @RequestMapping("/list/follow")
    public ApiResult searchAllFollowedStocks(@RequestParam("username") String username,
                                     @RequestParam("page") int page,
                                     @RequestParam("size") int size) {
        return ApiResultHandler.success(stockService.getAllFollowedStocksWithClose(6, page, size));
    }

    @RequestMapping("/{ts_code}")
    public ApiResult getOneStock(@PathVariable("ts_code") String ts_code) {
        return ApiResultHandler.success(stockService.getById(ts_code));
    }


}
