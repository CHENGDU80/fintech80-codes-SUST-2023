package com.taro.homework.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.taro.homework.entity.Stock;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;
import java.util.Map;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author taro
 * @since 2023-10-30
 */
public interface StockService extends IService<Stock> {

    public IPage<Map<String, String>> searchAllStocksByName(String name, int page, int size);

    public IPage<Map<String, String>> getAllStocksWithClose(int day, int page, int size);

    public IPage<Map<String, String>> getAllFollowedStocksWithClose(int day, int page, int size);
}
