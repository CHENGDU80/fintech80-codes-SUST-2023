package com.taro.homework.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.taro.homework.entity.User;
import com.taro.homework.entity.UserFollowStock;
import com.taro.homework.mapper.UserFollowStockMapper;
import com.taro.homework.service.UserFollowStockService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author taro
 * @since 2023-10-30
 */
@Service
public class UserFollowStockServiceImpl extends ServiceImpl<UserFollowStockMapper, UserFollowStock> implements UserFollowStockService {

    @Autowired
    UserFollowStockMapper userFollowStockMapper;

    @Override
    public boolean insertOrUpdateUfs(UserFollowStock userFollowStock) {
        QueryWrapper<UserFollowStock> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("user_id", userFollowStock.getUserId());
        queryWrapper.eq("ts_code", userFollowStock.getTsCode());
        if(userFollowStockMapper.selectOne(queryWrapper) != null) {
            UserFollowStock oldUserFollowStock = userFollowStockMapper.selectOne(queryWrapper);
            UpdateWrapper<UserFollowStock> updateWrapper = new UpdateWrapper<>();
            updateWrapper.eq("user_id", userFollowStock.getUserId())
                    .eq("ts_code", userFollowStock.getTsCode());
            userFollowStock.setFollowed(!oldUserFollowStock.getFollowed());
            int updatedRows = userFollowStockMapper.update(userFollowStock, updateWrapper);
            return updatedRows > 0;  // 更新成功
        } else {
            userFollowStockMapper.insert(userFollowStock);
            return true; //插入成功
        }
    }
}
