package com.taro.homework.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

@Configuration
public class DatabaseConfig {

    private static DatabaseConfig config;

    @Value(value = "${spring.datasource.driver-class-name}")
    public String DRIVER_CLASS_NAME;

    @Value(value = "${spring.datasource.url}")
    public String URL;

    @Value(value = "${spring.datasource.username}")
    public String USERNAME;

    @Value(value = "${spring.datasource.password}")
    public String PASSWORD;

    @Value(value = "${python.environment}")
    public String PYTHON_ENVIRONMENT;

    @Value(value = "${python.file-path.keyword}")
    public String FILE_PATH_KEYWORD;

    @Value(value = "${python.file-path.hot-for-java}")
    public String FILE_PATH_HOT_DOT;

    @Value(value = "${python.file-path.model}")
    public String FILE_PATH_MODEL;

    @Value(value = "${export-path.news}")
    public String EXPORT_NEWS;

    public static DatabaseConfig getDatabaseConfig() {
        if (config == null) {
            config = new DatabaseConfig();
            config.URL = "jdbc:mysql://localhost:3306/FINTECH80?serverTimezone=GMT%2B8&useUnicode=true&characterEncoding=UTF-8";
            config.USERNAME = "checker";
            config.PASSWORD = "123456";
        }
        return config;
    }

    public Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USERNAME, PASSWORD);
    }
}
