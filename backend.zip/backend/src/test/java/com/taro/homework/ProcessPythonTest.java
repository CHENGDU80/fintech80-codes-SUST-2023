package com.taro.homework;

import com.taro.homework.util.DataImportUtil;
import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

@SpringBootTest
public class ProcessPythonTest {

    @Test
    public void setUp() {

        try {
            String filePath = "D:\\CodeField\\CODE_JAVA\\CS309\\backend\\src\\main\\resources\\python\\hot_for_java.py";
            String keyPath = "F:\\FIN\\keyword.py";
            Process proc = DataImportUtil.buildProcess("python", filePath);
            String res = DataImportUtil.readInputStream(proc.getInputStream());
            String[] ss = res.split("\n");
            proc.waitFor();
            for (String s: ss) {
                Process p = DataImportUtil.buildProcess("python", keyPath, new String[]{s});
                String res1 = DataImportUtil.readInputStream(p.getInputStream());
                p.waitFor();
                System.out.println(res1);
            }
//            System.out.println(DataImportUtil.readInputStream(proc.getErrorStream()));
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
    }
}
