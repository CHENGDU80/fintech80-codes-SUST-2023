from model import Transformer
from dataset import KeywordDataset
import os
from torch.utils.data import DataLoader
import torch.nn as nn
import torch
from torch.utils.tensorboard import SummaryWriter
from tqdm import tqdm
from torch.optim.lr_scheduler import CosineAnnealingLR

root = '/data/chenjt/chengdu/dataset_float_label'
train_data = KeywordDataset(os.path.join(root, 'train.csv'))
train_dataloader = DataLoader(train_data, batch_size=4, shuffle=True, num_workers=4)
val_data = KeywordDataset(os.path.join(root, 'val.csv'))
val_dataloader = DataLoader(val_data, batch_size=1, shuffle=False, num_workers=4)
test_data = KeywordDataset(os.path.join(root, 'test.csv'))
test_dataloader = DataLoader(test_data, batch_size=1, shuffle=False, num_workers=4)

model = Transformer(num_layers=3, d_model=6000, num_heads=4, hidden_dim=3000)

criteon = nn.MSELoss()
optimizer = torch.optim.Adam(model.parameters(), lr=0.01)
scheduler = CosineAnnealingLR(optimizer, T_max=2000)
device = torch.device('cuda:6')
model.to(device)
print(device)

writer = SummaryWriter("./logs")
if not os.path.exists('./checkpoints'):
    os.makedirs('./checkpoints')
for epoch in range(2000):
    print(f'——————————————第 {epoch} 伦训练开始——————————————')
    model.train()
    train_cnt = 0
    epoch_train_loss = 0
    epoch_train_true_cnt = 0
    for bachidx, (x, targets) in tqdm(enumerate(train_dataloader)):
        x, targets = x.to(device), targets.to(device)
        logits = model(x)
        loss = criteon(logits[0], targets)
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        a = (logits[0] > 0) + 0
        b = (targets > 0) + 0
        epoch_train_true_cnt += torch.sum(((a - b)) == 0)

        train_cnt += x.shape[0]
        epoch_train_loss += loss * x.shape[0]
    scheduler.step()
    lr = scheduler.get_last_lr()
    train_loss = epoch_train_loss / train_cnt
    train_acc = epoch_train_true_cnt / (train_cnt * 5105)
    
    print(f'epoch[{epoch}]: Loss: {train_loss.item()}, Acc: {train_acc}, Learning Rate: {lr}')
    writer.add_scalar("train_loss", train_loss.item(), epoch)
    writer.add_scalar("train_acc", train_acc, epoch)

    # 验证步骤开始
    epoch_val_loss = 0
    val_cnt = 0
    epoch_val_true_cnt = 0
    with torch.no_grad():
        model.eval()
        for data in val_dataloader:
            x, targets = data
            x = x.to(device)
            
            targets = targets.to(device)
            out = model(x)
            loss = criteon(out[0].unsqueeze(0), targets)

            a = (out[0] > 0) + 0
            b = (targets > 0) + 0
            epoch_val_true_cnt += torch.sum(((a - b)) == 0)

            val_cnt += x.shape[0]
            epoch_val_loss += loss * x.shape[0]
        
        val_loss = epoch_val_loss / val_cnt
        val_acc = epoch_val_true_cnt / (val_cnt * 5105)
        print(f"val loss: {val_loss}, val acc: {val_acc}")
        writer.add_scalar('val_loss', val_loss, epoch)
    filepath = os.path.join("checkpoints", 'epoch_{}.pth'.format(epoch))
    torch.save(model.state_dict(), filepath)
writer.close()