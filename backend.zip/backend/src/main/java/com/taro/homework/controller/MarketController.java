package com.taro.homework.controller;


import com.taro.homework.entity.ApiResult;
import com.taro.homework.entity.Market;
import com.taro.homework.service.MarketService;
import com.taro.homework.util.ApiResultHandler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author taro
 * @since 2023-10-30
 */
@RestController
@RequestMapping("/api/market")
public class MarketController {

    @Autowired
    MarketService marketService;

    @RequestMapping("/day")
    public ApiResult searchDayByStock(@RequestParam("ts_code") String ts_code) {
        List<Market> market = marketService.getAllMarketOrderByDate(ts_code);
        List<List<Object>> strings = market.stream().map(market1 -> {
            List<Object> objects = new ArrayList<>();
            objects.add(market1.getTradeDate().format(DateTimeFormatter.ofPattern("yyyy/MM/dd")));
            objects.add(market1.getOpen());
            objects.add(market1.getClose());
            objects.add(market1.getHigh());
            objects.add(market1.getLow());
            return objects;
        }).collect(Collectors.toList());
        return ApiResultHandler.success(strings);
    }

    @RequestMapping("/szzs")
    public ApiResult searchSzzs() {
        return searchDayByStock("000001.SH");
    }
}
