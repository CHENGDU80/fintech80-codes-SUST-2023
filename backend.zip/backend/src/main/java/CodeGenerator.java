
import com.baomidou.mybatisplus.generator.FastAutoGenerator;
import com.baomidou.mybatisplus.generator.engine.FreemarkerTemplateEngine;

import com.baomidou.mybatisplus.generator.config.OutputFile;
import java.util.Collections;

public class CodeGenerator {
    //直接运行帮我们生成代码
    public static void main(String[] args) {

        String PROJECT_DIR = "D:\\CodeField\\CODE_JAVA\\CS309\\backend\\";

        String[] tables = new String[]{
                "market", "news", "stock",
                "tag", "tag_news", "user",
                "user_follow_stock"
        };


        FastAutoGenerator.create("jdbc:mysql://localhost:3306/FINTECH80?serverTimezone=GMT%2B8&useUnicode=true&characterEncoding=UTF-8", "checker", "123456")
                .globalConfig(builder -> {
                    builder.author("taro") // 设置作者
                            .enableSwagger() // 开启 swagger 模式
//                            .fileOverride() // 覆盖已生成文件
                            .outputDir(PROJECT_DIR+"src\\main\\java"); // 指定输出目录
                })
                .packageConfig(builder -> {
                    builder.parent("com.taro") // 设置父包名
                            .moduleName("homework") // 设置父包模块名
                            .pathInfo(Collections.singletonMap(OutputFile.mapperXml, PROJECT_DIR+"src\\main\\resources\\mapper\\")); // 设置mapperXml生成路径
                })
                .strategyConfig(builder -> {
                    builder.addInclude(tables) // 设置需要生成的表名
                            .addTablePrefix("t_", "c_") // 设置过滤表前缀
                            .entityBuilder()
                            .enableLombok()
                            .enableTableFieldAnnotation()
                             // Controller策略配置
                            .controllerBuilder()
                            .enableRestStyle() // 开启生成 @RestController 控制器
                            // Service策略配置
                            .serviceBuilder()
                            .formatServiceFileName("%sService")
                            .formatServiceImplFileName("%sServiceImpl")
                            // Mapper策略配置
                            .mapperBuilder();

                })
                .templateEngine(new FreemarkerTemplateEngine()) // 使用Freemarker引擎模板，默认的是Velocity引擎模板
                .execute();
    }
}
