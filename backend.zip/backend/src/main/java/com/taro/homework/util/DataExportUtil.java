package com.taro.homework.util;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

public class DataExportUtil {

    public static String toString(List<String> ss) {
        StringBuilder sb = new StringBuilder();
        sb.append("[");
        for (int i = 0; i < ss.size(); i++) {
            sb.append("\"");
            sb.append(ss.get(i).replace("\n", ""));
            sb.append("\"");
            if (i != ss.size()-1)
                sb.append(",");
        }
        sb.append("]");
        return sb.toString();
    }
    public static void toFile(String filePath, String content) {
        try {
            // 创建文件写入流
            FileWriter fileWriter = new FileWriter(filePath);
            BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);

            // 写入字符串内容
            bufferedWriter.write(content);

            // 关闭流
            bufferedWriter.close();
            fileWriter.close();

            System.out.println("成功将字符串写入文件：" + filePath);
        } catch (IOException e) {
            e.printStackTrace();
            System.err.println("写入文件时发生错误: " + e.getMessage());
        }
    }
}
