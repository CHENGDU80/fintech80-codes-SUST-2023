package com.taro.homework.controller;

import com.taro.homework.entity.ApiResult;
import com.taro.homework.util.ApiResultHandler;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/ai")
public class AIController {


    @RequestMapping("/industry")
    public ApiResult evalIndustry(@RequestParam("industry_name") String industryName) {
        return ApiResultHandler.success();
    }

    @RequestMapping("/news")
    public ApiResult evalNews(@RequestParam("id") int id) {
        return ApiResultHandler.success();
    }

    @RequestMapping("/stock")
    public ApiResult evalNews(@RequestParam("ts_code") String ts_code) {
        return ApiResultHandler.success();
    }

    @RequestMapping("/field")
    public ApiResult evalField(@RequestParam("field_name") String fieldName) {
        return ApiResultHandler.success();
    }
 }
