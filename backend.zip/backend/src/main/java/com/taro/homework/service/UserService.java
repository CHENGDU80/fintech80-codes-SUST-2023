package com.taro.homework.service;

import com.taro.homework.entity.User;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author taro
 * @since 2023-10-30
 */
public interface UserService extends IService<User> {

    public int getId(String username);
}
