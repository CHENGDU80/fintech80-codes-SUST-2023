package com.taro.homework.service.impl;

import com.taro.homework.entity.Market;
import com.taro.homework.mapper.MarketMapper;
import com.taro.homework.service.MarketService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author taro
 * @since 2023-10-30
 */
@Service
public class MarketServiceImpl extends ServiceImpl<MarketMapper, Market> implements MarketService {

    @Autowired
    MarketMapper marketMapper;

    @Override
    public List<Market> getAllMarketOrderByDate(String ts_code) {
        return marketMapper.getAllMarketOrderByDate(ts_code);
    }

    @Override
    public List<Map<String, String>> getAllMarketBeforeDays(String industryName, int day, int limit, String order) {
        return marketMapper.getAllMarketBeforeDays(industryName, day, limit, order);
    }

    @Override
    public List<Map<String, String>> getAllStocksHotByIndustry(String industryName, int limit) {
        return marketMapper.getAllStocksHotByIndustry(industryName, limit);
    }

    @Override
    public List<Map<String, String>> getAllHotNewsByIndustryAndStock(String industryName, String ts_code, int limit) {
        return marketMapper.getAllHotNewsByIndustryAndStock(industryName, ts_code, limit);
    }
}
