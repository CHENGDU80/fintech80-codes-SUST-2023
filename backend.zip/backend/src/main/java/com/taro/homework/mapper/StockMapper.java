package com.taro.homework.mapper;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.taro.homework.entity.Stock;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.Map;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author taro
 * @since 2023-10-30
 */
@Mapper
public interface StockMapper extends BaseMapper<Stock> {
    @Select("select ts_code, name, industry from stock where stock.name like CONCAT('%', #{name},'%')")
    public IPage<Map<String, String>> searchAllStocksByName(String name, Page page);

    @Select("SELECT stock.name, t.* FROM stock left join (SELECT * from market where market.trade_date = CURDATE() - INTERVAL #{day} DAY) as t on stock.ts_code = t.ts_code where t.ts_code not in ('000001.SH', '802046', '399441', '802089')")
    public IPage<Map<String, String>> getAllStocksWithClose(int day, Page page);

    @Select("SELECT u.* from user_follow_stock as ufs left join(SELECT stock.name, t.* FROM stock left join (SELECT * from market where market.trade_date = CURDATE() - INTERVAL #{day} DAY) as t on stock.ts_code = t.ts_code) as u on ufs.ts_code = u.ts_code where u.ts_code not in ('000001.SH', '802046', '399441', '802089')")
    public IPage<Map<String, String>> getAllFollowedStocksWithClose(int day, Page page);
}
