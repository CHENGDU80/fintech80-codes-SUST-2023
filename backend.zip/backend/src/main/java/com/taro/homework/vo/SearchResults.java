package com.taro.homework.vo;

public class SearchResults {


}
