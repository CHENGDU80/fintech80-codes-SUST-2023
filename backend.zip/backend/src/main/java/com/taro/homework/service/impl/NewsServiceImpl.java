package com.taro.homework.service.impl;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.taro.homework.entity.News;
import com.taro.homework.mapper.NewsMapper;
import com.taro.homework.service.NewsService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Map;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author taro
 * @since 2023-10-30
 */
@Service
public class NewsServiceImpl extends ServiceImpl<NewsMapper, News> implements NewsService {

    @Autowired
    NewsMapper newsMapper;

    @Override
    public IPage<News> getAllNewsByKeywords(String keyword, int page, int size) {
        Page<News> page1 = new Page<>(page, size);
        return newsMapper.getAllNewsByChannels(keyword, page1);
    }

    @Override
    public IPage<News> getAllNewsOrderByDate(int page, int size) {
        Page<News> page1 = new Page<>(page, size);
        return newsMapper.getAllNewsOrderByDate(page1);
    }

    @Override
    public IPage<Map<String, String>> getAllNewsByFieldOrderByDate(String keyword, int page, int size) {
        Page<News> page1 = new Page<>(page, size);
        return newsMapper.getAllNewsByFieldOrderByDate(keyword, page1);
    }

    @Override
    public IPage<Map<String, String>> getAllMacroNewsOrderByDate(int page, int size) {
        Page<News> page1 = new Page<>(page, size);
        return newsMapper.getAllMacroNewsOrderByDate(page1);
    }

    @Override
    public int getNumberOfNews(String keyword) {
        return newsMapper.getNumberOfNews(keyword);
    }

    @Override
    public IPage<News> getAllHotNewsWithKeywords(String key1, String key2, String key3, int page, int size) {
        Page<News> page1 = new Page<>();
        return newsMapper.getAllHotNewsWithKeywords(key1, key2, key3, page1);
    }
}
