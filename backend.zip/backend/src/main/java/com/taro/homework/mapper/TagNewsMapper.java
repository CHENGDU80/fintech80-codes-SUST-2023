package com.taro.homework.mapper;

import com.taro.homework.entity.TagNews;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author taro
 * @since 2023-10-30
 */
public interface TagNewsMapper extends BaseMapper<TagNews> {

}
