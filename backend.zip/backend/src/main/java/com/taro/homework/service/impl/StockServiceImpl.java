package com.taro.homework.service.impl;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.taro.homework.entity.Stock;
import com.taro.homework.mapper.StockMapper;
import com.taro.homework.service.StockService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author taro
 * @since 2023-10-30
 */
@Service
public class StockServiceImpl extends ServiceImpl<StockMapper, Stock> implements StockService {

    @Autowired
    StockMapper stockMapper;

    @Override
    public IPage<Map<String, String>> searchAllStocksByName(String name, int page, int size) {
        Page<Map<String, String>> page1 = new Page<>(page, size);
        return stockMapper.searchAllStocksByName(name, page1);
    }

    @Override
    public IPage<Map<String, String>> getAllStocksWithClose(int day, int page, int size) {
        Page<Map<String, String>> page1 = new Page<>(page, size);
        return stockMapper.getAllStocksWithClose(day, page1);
    }

    @Override
    public IPage<Map<String, String>> getAllFollowedStocksWithClose(int day, int page, int size) {
        Page<Map<String, String>> page1 = new Page<>(page, size);
        return stockMapper.getAllFollowedStocksWithClose(day, page1);
    }
}
