package com.taro.homework.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 *
 * </p>
 *
 * @author taro
 * @since 2023-10-30
 */
@Data
@TableName("user_follow_stock")
@ApiModel(value = "UserFollowStock对象", description = "")
public class UserFollowStock implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableField("user_id")
    private Integer userId;

    @TableField("ts_code")
    private String tsCode;

    @TableField("followed")
    private Boolean followed;

    public UserFollowStock(int id, String ts_code, boolean b) {
        userId = id;
        this.tsCode = ts_code;
        this.followed = b;
    }
}
