package com.taro.homework.controller;

import com.taro.homework.entity.ApiResult;
import com.taro.homework.entity.Market;
import com.taro.homework.service.MarketService;
import com.taro.homework.service.NewsService;
import com.taro.homework.util.ApiResultHandler;
import io.swagger.models.auth.In;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/industry")
public class IndustryController {
    @Autowired
    MarketService marketService;

    @Autowired
    NewsService newsService;

    @RequestMapping("/stock/list")
    public ApiResult getDragonTiger(@RequestParam("industry_name") String industryName,
                                    @RequestParam("before_day") int day,
                                    @RequestParam("pct_chg_order") String order,
                                    @RequestParam(value = "limit", required = false) Integer limit) {
        if (limit == null)
            limit = 5;
        if (order.equals("asc")) {
            order = "desc";
        } else if (order.equals("desc")) {
            order = "asc";
        } else {
            return ApiResultHandler.buildApiResult(301, "Invalid order", null);
        }
        return ApiResultHandler.success(marketService.getAllMarketBeforeDays(industryName, day, limit, order));
    }

    @RequestMapping("/stock/list/hot")
    public ApiResult getAllStocksByHot(@RequestParam("industry_name") String industryName) {
        return ApiResultHandler.success(marketService.getAllStocksHotByIndustry(industryName, 10));
    }

    @RequestMapping("/news/list/hot")
    public ApiResult getAllNewsByIndustryAndStock(@RequestParam("industry_name") String industryName,
                                                  @RequestParam("ts_code") String ts_code) {
        return ApiResultHandler.success(marketService.getAllHotNewsByIndustryAndStock(industryName, ts_code, 10));
    }

    @RequestMapping("/semi/graph")
    public ApiResult getSemiKGraph() {
        List<Market> market = marketService.getAllMarketOrderByDate("802046");
        List<List<Object>> strings = market.stream().map(market1 -> {
            List<Object> objects = new ArrayList<>();
            objects.add(market1.getTradeDate().format(DateTimeFormatter.ofPattern("yyyy/MM/dd")));
            objects.add(market1.getOpen());
            objects.add(market1.getClose());
            objects.add(market1.getHigh());
            objects.add(market1.getLow());
            return objects;
        }).collect(Collectors.toList());
        return ApiResultHandler.success(strings);
    }

    @RequestMapping("/bio/graph")
    public ApiResult getBioKGraph() {
        List<Market> market = marketService.getAllMarketOrderByDate("399441");
        List<List<Object>> strings = market.stream().map(market1 -> {
            List<Object> objects = new ArrayList<>();
            objects.add(market1.getTradeDate().format(DateTimeFormatter.ofPattern("yyyy/MM/dd")));
            objects.add(market1.getOpen());
            objects.add(market1.getClose());
            objects.add(market1.getHigh());
            objects.add(market1.getLow());
            return objects;
        }).collect(Collectors.toList());
        return ApiResultHandler.success(strings);
    }

    @RequestMapping("/bank/graph")
    public ApiResult getBankKGraph() {
        List<Market> market = marketService.getAllMarketOrderByDate("802089");
        List<List<Object>> strings = market.stream().map(market1 -> {
            List<Object> objects = new ArrayList<>();
            objects.add(market1.getTradeDate().format(DateTimeFormatter.ofPattern("yyyy/MM/dd")));
            objects.add(market1.getOpen());
            objects.add(market1.getClose());
            objects.add(market1.getHigh());
            objects.add(market1.getLow());
            return objects;
        }).collect(Collectors.toList());
        return ApiResultHandler.success(strings);
    }

    @RequestMapping("/cloud")
    public ApiResult cloudGraph() {
        List<String> produces = Arrays.asList("玉米", "大豆", "小麦", "燕麦", "水稻", "牛", "可可", "羊毛", "棉花", "大豆油", "菜籽油", "鸡蛋", "猪", "羊毛", "棕榈油");
        List<String> metals = Arrays.asList("黄金", "银", "铜", "铁", "铝", "镍", "铁矿石", "铂金", "锌", "铅", "硅", "镁", "氧化铝", "锡");
        List<String> resources = Arrays.asList("原油", "燃料", "沥青", "纸浆", "天然气", "甲醇", "聚乙烯", "玻璃", "纯碱", "尿素", "煤炭", "纤维板", "PVC");
        List<Map<String, String>> produceMapList = new ArrayList<>();
        List<Map<String, String>> metalMapList = new ArrayList<>();
        List<Map<String, String>> resourceMapList = new ArrayList<>();
        for (String produce : produces) {
            int no = newsService.getNumberOfNews(produce);
            if (no == 0)
                no = 1;
            Map<String, String> produceMap = new HashMap<>();
            produceMap.put("name", produce);
            produceMap.put("value", String.valueOf(no));
            produceMapList.add(produceMap);
        }
        for (String metal: metals) {
            int no = newsService.getNumberOfNews(metal);
            if (no == 0)
                no = 1;
            Map<String, String> metalMap = new HashMap<>();
            metalMap.put("name", metal);
            metalMap.put("value", String.valueOf(no));
            metalMapList.add(metalMap);
        }
        for (String resource: resources) {
            int no = newsService.getNumberOfNews(resource);
            if (no == 0)
                no = 1;
            Map<String, String> resourceMap = new HashMap<>();
            resourceMap.put("name", resource);
            resourceMap.put("value", String.valueOf(no));
            resourceMapList.add(resourceMap);
        }
        Map<String, List<Map<String, String>>> res = new HashMap<>();
        res.put("农产品", produceMapList);
        res.put("金属与矿石", metalMapList);
        res.put("能源化工", resourceMapList);
        return ApiResultHandler.success(res);
    }
}
