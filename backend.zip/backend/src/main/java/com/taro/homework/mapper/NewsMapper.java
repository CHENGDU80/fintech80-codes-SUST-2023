package com.taro.homework.mapper;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.taro.homework.entity.News;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;
import java.util.Map;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author taro
 * @since 2023-10-30
 */
@Mapper
public interface NewsMapper extends BaseMapper<News> {

    @Select("select * from news where content like CONCAT('%', #{industryName}, '%')")
    public IPage<News> getAllNewsByChannels(String industryName, Page page);

    @Select("SELECT * FROM news where news.content LIKE CONCAT('%', #{keyword}, '%') ORDER BY released_time desc")
    public IPage<Map<String, String>> getAllNewsByFieldOrderByDate(String keyword, Page page);

    @Select("SELECT * FROM news where (news.channel LIKE '%市场%' OR news.channel LIKE '%国际%' OR news.channel LIKE '%宏观%') AND news.title is not null ORDER BY released_time desc")
    public IPage<Map<String, String>> getAllMacroNewsOrderByDate(Page page);

    @Select("SELECT * FROM news ORDER BY released_time desc")
    IPage<News> getAllNewsOrderByDate(Page<News> page1);

    @Select("select count(1) from news where news.content like CONCAT('%', #{keyword} ,'%')")
    int getNumberOfNews(String keyword);

    @Select("SELECT id, title, content, released_time, channel FROM news where news.content LIKE CONCAT('%', #{key1},'%') AND news.content LIKE CONCAT('%', #{key2},'%') AND news.content LIKE CONCAT('%', #{key3},'%') ORDER BY released_time desc")
    IPage<News> getAllHotNewsWithKeywords(String key1, String key2, String key3, Page<News> page);
}
