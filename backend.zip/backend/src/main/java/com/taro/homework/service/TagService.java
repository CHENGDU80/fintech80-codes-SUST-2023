package com.taro.homework.service;

import com.taro.homework.entity.Tag;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author taro
 * @since 2023-10-30
 */
public interface TagService extends IService<Tag> {

}
